package org.example;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.apache.http.HttpHeaders;
import java.net.HttpURLConnection;
import org.apache.http.client.methods.*;
import org.apache.http.entity.ContentType;
import org.apache.poi.EmptyFileException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ExecutionException;

import org.apache.http.entity.FileEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.*;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class AprimoUploader {

    // SharePoint credentials
    private static final String SHAREPOINT_SITE_NAME = "sanitarium_aprimo_asset";
    private static final String SP_TENANT_ID = "396f5882-803a-4ab2-a15c-cfaf37a12212";
    private static final String SP_CLIENT_ID = "a279d93b-83b5-4650-8df0-88ba3156a8c6";
    private static final String SP_CLIENT_SECRET = "FRo8Q~uvUIuqSN2A4kUd3dHUf.v3r.gP2e3CdcPT";
    private static final String SP_DRIVE_ID = "b!qb6egh9IQEqB1GG_7sQS3f9PMgEPlwFDphOxpzmIhmeEqwt8r7yaRr998YZOizIi";
    private static final String SHAREPOINT_SITE_ID = "dluxtechcorp.sharepoint.com,sites," + SHAREPOINT_SITE_NAME;

    // Aprimo credentials
    private static final String APRIMO_TOKEN_URL = "https://partnerdemo103.aprimo.com/login/connect/token";
    private static final String APRIMO_CLIENT_ID = "3FR7U1CD-3FR7";
    private static final String APRIMO_CLIENT_SECRET = "Vennilak@03";
    private static final String UPLOAD_BASE_URL = "https://partnerdemo103.aprimo.com/uploads";
    private static final String API_BASE_URL = "https://partnerdemo103.dam.aprimo.com";
    private static final String CLASSIFICATION_ID = "8515da41-a5f5-44bb-8c83-abc600c6a400";
    private static final long CHUNK_SIZE = 20 * 1024 * 1024; // 20 MB

    // Retry configuration
    private static final int MAX_RETRIES = 3;
    private static final long RETRY_DELAY_MS = 2000; // 2 seconds between retries
    private static final long MIN_FILE_SIZE = 1; // Minimum valid file size in bytes

    @FunctionalInterface
    private interface RetryableOperation<T> {
        T execute() throws Exception;
    }

    private static <T> T executeWithRetry(RetryableOperation<T> operation, String operationName) throws Exception {
        int attempt = 0;
        Exception lastException = null;
        long baseDelayMs = RETRY_DELAY_MS;

        while (attempt < MAX_RETRIES) {
            attempt++;
            try {
                System.out.printf("🔄 Attempt %d/%d for %s...%n", attempt, MAX_RETRIES, operationName);
                T result = operation.execute();
                if (attempt > 1) {
                    System.out.printf("✅ Attempt %d/%d succeeded for %s%n", attempt, MAX_RETRIES, operationName);
                }
                return result;

            } catch (Exception e) {
                lastException = e;
                System.err.printf("⚠️ Attempt %d/%d failed for %s: %s%n",
                        attempt, MAX_RETRIES, operationName, e.getMessage());

                if (e instanceof IOException && e.getMessage().contains("429")) {
                    long backoffTime = (long) (Math.pow(2, attempt) * baseDelayMs);
                    System.err.printf("⏳ 429 Too Many Requests detected. Waiting %d ms before retry...%n", backoffTime);
                    try {
                        Thread.sleep(backoffTime);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("Retry interrupted", ie);
                    }
                } else if (attempt < MAX_RETRIES) {
                    try {
                        System.out.printf("⏳ Waiting before next attempt (%d/%d)...%n", attempt+1, MAX_RETRIES);
                        Thread.sleep(baseDelayMs);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new RuntimeException("Retry interrupted", ie);
                    }
                }
            }
        }

        System.err.printf("❌ Operation %s failed after %d attempts. Skipping...%n", operationName, MAX_RETRIES);
        throw lastException != null ? lastException : new RuntimeException("Operation failed");
    }

    public static void main(String[] args) {
        try {
            // First try to process SharePoint files if CSV exists
            try {
                String spToken = executeWithRetry(AprimoUploader::getSharePointToken, "getSharePointToken");
                final String finalSpToken = spToken;
                String resolvedSiteId = executeWithRetry(() -> resolveSiteId(finalSpToken), "resolveSiteId");
                String aprimoToken = executeWithRetry(AprimoUploader::getAprimoToken, "getAprimoToken");

                final String finalResolvedSiteId = resolvedSiteId;
                List<JsonNode> files = executeWithRetry(() -> listFilesInFolder(finalResolvedSiteId, finalSpToken), "listFilesInFolder");
                JsonNode csvFile = null;
                for (JsonNode file : files) {
                    if (file.get("name").asText().endsWith(".csv")) {
                        csvFile = file;
                        break;
                    }
                }

                if (csvFile != null) {
                    String csvName = csvFile.get("name").asText();
                    String downloadUrl = csvFile.get("@microsoft.graph.downloadUrl").asText();
                    System.out.println("\n📄 CSV File Found: " + csvName);

                    final String finalDownloadUrl = downloadUrl;
                    File localCsv = executeWithRetry(() -> downloadAsset(finalDownloadUrl, finalSpToken), "downloadAsset");

                    if (localCsv == null || !localCsv.exists()) {
                        System.err.println("❌ Error: CSV file download failed");
                        return;
                    }

                    if (localCsv.length() < MIN_FILE_SIZE) {
                        System.err.println("❌ Error: Downloaded CSV file is empty (0 bytes)");
                        localCsv.delete();
                        return;
                    }

                    processCsv(localCsv, finalSpToken, aprimoToken);
                    return;
                }
            } catch (EmptyFileException e) {
                System.err.println("❌ Empty CSV file detected: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("⚠️ SharePoint processing failed, falling back to local files: " + e.getMessage());
            }

            System.out.println("🔍 No CSV found in SharePoint, checking for local files...");
            // Local file processing logic would go here

        } catch (Exception e) {
            System.err.println("❌ General Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void processCsv(File localCsv, String spToken, String aprimoToken) {
        if (localCsv == null || !localCsv.exists() || localCsv.length() < MIN_FILE_SIZE) {
            System.err.println("❌ Error: Invalid or empty CSV file");
            if (localCsv != null && localCsv.exists()) {
                localCsv.delete();
            }
            return;
        }

        boolean allUploadsSuccessful = true;
        String logFileName = SHAREPOINT_SITE_NAME + "_log_file.xlsx";
        File logFile = new File(System.getProperty("java.io.tmpdir"), logFileName);
        ExcelLogger logger = null;
        ExecutorService executor = Executors.newFixedThreadPool(3);
        List<Future<?>> futures = new ArrayList<>();

        try {
            logger = new ExcelLogger(logFile.getAbsolutePath());

            CSVFormat format = CSVFormat.DEFAULT
                    .withFirstRecordAsHeader()
                    .withIgnoreSurroundingSpaces()
                    .withTrim()
                    .withDelimiter(';')
                    .withQuote('"')
                    .withIgnoreEmptyLines();

            Map<String, Integer> filteredHeaders = new LinkedHashMap<>();
            try (Reader headerReader = new FileReader(localCsv);
                 CSVParser headerParser = new CSVParser(headerReader, format)) {

                if (headerParser.getHeaderMap().isEmpty()) {
                    throw new EmptyFileException(localCsv);                }

                for (Map.Entry<String, Integer> entry : headerParser.getHeaderMap().entrySet()) {
                    String key = entry.getKey();
                    if (key != null && !key.trim().isEmpty()) {
                        filteredHeaders.put(key.trim(), entry.getValue());
                    }
                }
            }

            try (Reader mainReader = new FileReader(localCsv);
                 CSVParser parser = new CSVParser(mainReader, format.withHeader(filteredHeaders.keySet().toArray(new String[0])))) {

                if (!filteredHeaders.containsKey("Folder_path")) {
                    throw new IllegalArgumentException("❌ Missing 'Folder_path' column in CSV.");
                }

                final List<String> originalHeaders = new ArrayList<>(filteredHeaders.keySet());

                for (CSVRecord record : parser) {
                    final CSVRecord finalRecord = record;
                    final ExcelLogger logRef = logger;

                    futures.add(executor.submit(() -> {
                        String folderPath = finalRecord.get("Folder_path").trim();
                        if (folderPath.isEmpty()) {
                            System.out.println("⚠️ Skipping row with empty Folder_path.");
                            return null;
                        }

                        File assetFile = null;
                        File singleCsv = null;
                        String downloadStatus = "Success", uploadStatus = "Failure", metadataStatus = "Not Applied", errorMessage = "-";
                        String downloadTime = "-", uploadTime = "-", recordId = "-";

                        try {
                            long startDownload = System.currentTimeMillis();
                            assetFile = executeWithRetry(() -> downloadAsset(folderPath, spToken), "downloadAsset");

                            if (assetFile == null || !assetFile.exists() || assetFile.length() == 0) {
                                throw new IOException("Downloaded asset file is empty or invalid");
                            }

                            long endDownload = System.currentTimeMillis();
                            downloadTime = ((endDownload - startDownload) / 1000) + "s";

                            final File finalAssetFile = assetFile;
                            singleCsv = createSingleRowMetadataCsv(finalRecord, originalHeaders);
                            final File finalCsv = singleCsv;

                            String metadataToken = executeWithRetry(() -> uploadCsvAndGetToken(finalCsv, aprimoToken), "uploadCsvAndGetToken");

                            UploadInfo info = executeWithRetry(() -> startUploadSession(aprimoToken, finalAssetFile), "startUploadSession");

                            long startUpload = System.currentTimeMillis();
                            boolean uploadSuccess;
                            if (assetFile.length() > 20 * 1024 * 1024) {
                                uploadSuccess = executeWithRetry(() -> uploadViaAzCopy(finalAssetFile, info.sasUrl), "uploadViaAzCopy");
                            } else {
                                uploadSuccess = executeWithRetry(() -> uploadToAprimo(info.sasUrl, finalAssetFile), "uploadToAprimo");
                            }
                            long endUpload = System.currentTimeMillis();
                            uploadTime = ((endUpload - startUpload) / 1000) + "s";

                            if (!uploadSuccess) {
                                throw new IOException("Upload failed for: " + finalAssetFile.getName());
                            }

                            recordId = executeWithRetry(() -> createAssetRecordAndReturnId(
                                    HttpClients.createDefault(), aprimoToken, info.token, metadataToken, finalAssetFile.getName()
                            ), "createAssetRecord");

                            if (recordId != null && !recordId.equals("-")) {
                                uploadStatus = "Success";
                                metadataStatus = "Applied";
                                System.out.println("✅ Uploaded & Created Asset: " + finalAssetFile.getName());
                            }

                        } catch (Exception e) {
                            synchronized (System.err) {
                                System.err.println("❌ Error processing asset: " + folderPath);
                                e.printStackTrace();
                            }
                            downloadStatus = "Failure";
                            errorMessage = e.getMessage();
                        } finally {
                            if (singleCsv != null && singleCsv.exists()) singleCsv.delete();
                            if (assetFile != null && assetFile.exists()) {
                                File parentDir = assetFile.getParentFile();
                                assetFile.delete();
                                if (parentDir != null && parentDir.exists()) parentDir.delete();
                            }
                        }

                        synchronized (logRef) {
                                 logRef.log(new LogEntry(
                                         assetFile != null ? assetFile.getName() : "-",
                                         folderPath,
                                         downloadStatus,
                                         uploadStatus,
                                         downloadTime,
                                         uploadTime,
                                         errorMessage,
                                         metadataStatus,
                                         recordId
                                 ));
                             }

                             return null;
                         }));
                     }
                 }

            for (Future<?> future : futures) {
                try {
                    future.get();
                } catch (Exception e) {
                    allUploadsSuccessful = false;
                    e.printStackTrace();
                }
            }

        } catch (EmptyFileException e) {
            System.err.println("❌ Empty CSV file error: " + e.getMessage());
            allUploadsSuccessful = false;
        } catch (Exception e) {
            allUploadsSuccessful = false;
            System.err.println("❌ Error processing CSV: " + e.getMessage());
            e.printStackTrace();
        } finally {
            executor.shutdown();
            if (logger != null) {
                try {
                    logger.close();
                    uploadFileToSharePoint(spToken, logFile);
                    if (logFile.exists()) logFile.delete();
                } catch (Exception e) {
                    System.err.println("⚠️ Failed to upload log: " + e.getMessage());
                }
            }

            if (localCsv != null && localCsv.exists()) {
                if (localCsv.delete()) {
                    System.out.println("🧹 Deleted metadata CSV: " + localCsv.getName());
                } else {
                    System.err.println("⚠️ Failed to delete metadata CSV: " + localCsv.getAbsolutePath());
                }
            }
        }
    }

    private static class UploadInfo {
        String token, sasUrl;
        UploadInfo(String token, String sasUrl) {
            this.token = token;
            this.sasUrl = sasUrl;
        }
    }

    private static UploadInfo startUploadSession(String token, File file) throws IOException {
        String url = UPLOAD_BASE_URL;

        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost(url);
            post.setHeader("Authorization", "Bearer " + token);
            post.setHeader("API-VERSION", "1");
            post.setHeader("Content-Type", "application/json");
            final ObjectMapper mapper = new ObjectMapper();
            ObjectNode payload = mapper.createObjectNode();
            payload.put("filename", file.getName());
            payload.put("size", file.length());

            post.setEntity(new StringEntity(payload.toString(), ContentType.APPLICATION_JSON));

            try (CloseableHttpResponse resp = client.execute(post)) {
                JsonNode json = mapper.readTree(resp.getEntity().getContent());
                if (json.has("token") && json.has("sasUrl")) {
                    return new UploadInfo(json.get("token").asText(), json.get("sasUrl").asText());
                }
                return null;
            }
        }
    }

    private static boolean uploadToAprimo(String sasUrl, File file) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder("azcopy", "copy", file.getAbsolutePath(), sasUrl, "--overwrite=true");
        pb.inheritIO();
        Process process = pb.start();
        int exitCode = process.waitFor();
        return exitCode == 0;
    }

    public static File createSingleRowMetadataCsv(CSVRecord record, List<String> headers) throws IOException {
        File tempCsv = File.createTempFile("single_asset_metadata_", ".csv");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(tempCsv))) {
            if (!headers.contains("Folder_path")) {
                throw new IllegalArgumentException("CSV must have 'Folder_path' column.");
            }

            writer.write(String.join(";", headers));
            writer.newLine();

            List<String> row = new ArrayList<>();
            for (String header : headers) {
                String value = record.isMapped(header) ? record.get(header) : "";
                row.add("\"" + value + "\"");
            }

            writer.write(String.join(";", row));
            writer.newLine();
        }

        return tempCsv;
    }

    private static File downloadAsset(String shareLink, String spToken) throws IOException, InterruptedException {
        if (shareLink == null || shareLink.isEmpty()) {
            throw new IOException("❌ Empty share link (Folder_path is blank)");
        }

        String encodedUrl = Base64.getUrlEncoder().encodeToString(shareLink.getBytes(StandardCharsets.UTF_8));
        String graphUrl = "https://graph.microsoft.com/v1.0/shares/u!" + encodedUrl + "/driveItem";

        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpGet get = new HttpGet(graphUrl);
            get.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + spToken);
            get.setHeader(HttpHeaders.ACCEPT, "application/json");

            try (CloseableHttpResponse response = client.execute(get)) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(response.getEntity().getContent());

                if (root.has("@microsoft.graph.downloadUrl") && root.has("size") && root.has("id") && root.has("name")) {
                    long fileSize = root.get("size").asLong();
                    if (fileSize == 0) {
                        throw new IllegalStateException("Downloaded file is empty (0 bytes)");
                    }
                    String fileId = root.get("id").asText();
                    String fileName = root.get("name").asText();
                    return downloadFileParallel(spToken, fileId, fileName);
                } else {
                    throw new IOException("❌ No download URL or size or ID found.");
                }
            }
        }
    }

    private static File downloadFileParallel(String accessToken, String fileId, String fileName) throws IOException, InterruptedException {
        // Get file metadata (size)
        String metaUrl = "https://graph.microsoft.com/v1.0/drives/" + SP_DRIVE_ID + "/items/" + fileId;
        HttpURLConnection metaConn = (HttpURLConnection) new URL(metaUrl).openConnection();
        metaConn.setRequestProperty("Authorization", "Bearer " + accessToken);
        metaConn.setRequestMethod("GET");
        JsonNode fileMeta = new ObjectMapper().readTree(metaConn.getInputStream());
        long fileSize = fileMeta.get("size").asLong();
        metaConn.disconnect();

        

        // Create unique temp directory
        File tempDir = Files.createTempDirectory("az_temp_").toFile();
        File file = new File(tempDir, fileName);

        try (RandomAccessFile raf = new RandomAccessFile(file, "rw")) {
            raf.setLength(fileSize);
        }

        int numThreads = 8;
        long chunkSize = fileSize / numThreads;
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        List<Future<Boolean>> futures = new ArrayList<>();
        AtomicLong downloadedBytes = new AtomicLong(0);
        AtomicInteger done = new AtomicInteger(0), failed = new AtomicInteger(0), skipped = new AtomicInteger(0);
        long startTime = System.currentTimeMillis();

        // Progress logger
        ScheduledExecutorService progressExecutor = Executors.newSingleThreadScheduledExecutor();
        progressExecutor.scheduleAtFixedRate(() -> {
            long downloaded = downloadedBytes.get();
            double percent = (downloaded * 100.0) / fileSize;
            double elapsedSec = (System.currentTimeMillis() - startTime) / 1000.0;
            double speedMbps = (downloaded / 1024.0 / 1024.0) / (elapsedSec == 0 ? 1 : elapsedSec);
            int pending = numThreads - (done.get() + failed.get() + skipped.get());

            System.out.print(String.format(
                    "\r⬇️ Downloading [%s] %.2f%% | %d Done, %d Failed, %d Pending, %d Skipped, %d Total | %.4f Mb/s",
                    fileName, percent, done.get(), failed.get(), pending, skipped.get(), numThreads, speedMbps));
        }, 0, 2, TimeUnit.SECONDS);

        // Parallel chunk downloads
        for (int i = 0; i < numThreads; i++) {
            long start = i * chunkSize;
            long end = (i == numThreads - 1) ? fileSize - 1 : (start + chunkSize - 1);
            final int part = i;

            futures.add(executor.submit(() -> {
                int retry = 0;
                while (retry < 3) {
                    try (RandomAccessFile out = new RandomAccessFile(file, "rw")) {
                        HttpURLConnection conn = (HttpURLConnection) new URL("https://graph.microsoft.com/v1.0/drives/" + SP_DRIVE_ID + "/items/" + fileId + "/content").openConnection();
                        conn.setRequestProperty("Authorization", "Bearer " + accessToken);
                        conn.setRequestProperty("Range", "bytes=" + start + "-" + end);
                        conn.connect();

                        try (InputStream in = conn.getInputStream()) {
                            out.seek(start);
                            byte[] buffer = new byte[1024 * 1024]; // 1MB buffer
                            int bytesRead;
                            while ((bytesRead = in.read(buffer)) != -1) {
                                out.write(buffer, 0, bytesRead);
                                downloadedBytes.addAndGet(bytesRead);
                            }
                        }

                        done.incrementAndGet();
                        return true;

                    } catch (IOException e) {
                        retry++;
                        System.err.printf("\n❌ Chunk %d failed (try %d): %s\n", part, retry, e.getMessage());
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            return false;
                        }
                    }
                }

                failed.incrementAndGet();
                return false;
            }));
        }

        // Await completion
        try {
            for (Future<Boolean> future : futures) {
                future.get();
            }
        } catch (ExecutionException e) {
            throw new IOException("❌ Parallel download failed", e);
        } finally {
            executor.shutdown();
            progressExecutor.shutdownNow();
        }

        System.out.println();
        System.out.println("✅ Parallel download completed: " + fileName);

        // Return file WITH reference to its tempDir for cleanup after upload
        file.deleteOnExit(); // in case something fails
        file.getParentFile().deleteOnExit(); // mark folder for deletion

        return file;
    }

    private static String getSharePointToken() throws IOException {
        String url = "https://login.microsoftonline.com/" + SP_TENANT_ID + "/oauth2/v2.0/token";

        String body = "grant_type=client_credentials" +
                "&client_id=" + URLEncoder.encode(SP_CLIENT_ID, StandardCharsets.UTF_8) +
                "&client_secret=" + URLEncoder.encode(SP_CLIENT_SECRET, StandardCharsets.UTF_8) +
                "&scope=" + URLEncoder.encode("https://graph.microsoft.com/.default", StandardCharsets.UTF_8);

        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost(url);
            post.setHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded");
            post.setEntity(new InputStreamEntity(new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8))));

            try (CloseableHttpResponse response = client.execute(post)) {
                ObjectMapper mapper = new ObjectMapper();
                String jsonString = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))
                        .lines().reduce("", (acc, line) -> acc + line);

                System.out.println("🔍 SharePoint Token Response: " + jsonString);

                JsonNode json = mapper.readTree(jsonString);
                if (json.has("access_token")) {
                    return json.get("access_token").asText();
                } else {
                    throw new RuntimeException("❌ No access_token found. Full response: " + jsonString);
                }
            }
        }
    }

    private static String resolveSiteId(String spToken) throws IOException {
        String hostname = "dluxtechcorp.sharepoint.com";
        String sitePath = "/sites/sanitarium_aprimo_asset";
        String url = String.format("https://graph.microsoft.com/v1.0/sites/%s:%s", hostname, sitePath);

        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpGet get = new HttpGet(url);
            get.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + spToken);
            get.setHeader(HttpHeaders.ACCEPT, "application/json");

            try (CloseableHttpResponse response = client.execute(get)) {
                ObjectMapper mapper = new ObjectMapper();
                JsonNode root = mapper.readTree(response.getEntity().getContent());

                if (root.has("id")) {
                    System.out.println("✅ SharePoint Site ID: " + root.get("id").asText());
                    return root.get("id").asText();
                } else {
                    throw new RuntimeException("❌ Could not resolve SharePoint site ID: " + root.toPrettyString());
                }
            }
        }
    }

    private static List<JsonNode> listFilesInFolder(String siteId, String token) throws IOException {
        List<JsonNode> result = new ArrayList<>();
        String url = String.format("https://graph.microsoft.com/v1.0/sites/%s/drives/%s/root/children",
                siteId,
                SP_DRIVE_ID);

        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpGet get = new HttpGet(url);
            get.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + token);
            get.setHeader(HttpHeaders.ACCEPT, "application/json");

            try (CloseableHttpResponse response = client.execute(get)) {
                ObjectMapper mapper = new ObjectMapper();
                String rawJson = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))
                        .lines().reduce("", (acc, line) -> acc + line);

                JsonNode root = mapper.readTree(rawJson);
                if (root.has("value")) {
                    for (JsonNode file : root.get("value")) {
                        result.add(file);
                    }
                } else {
                    throw new RuntimeException("❌ 'value' not found in SharePoint response. Full response: " + rawJson);
                }
            }
        }

        return result;
    }

    public static boolean uploadViaAzCopy(File file, String sasUrl) throws IOException, InterruptedException {
        File tempAzCopyLogDir = Files.createTempDirectory("azcopy_temp_logs").toFile();

        List<String> command = Arrays.asList(
                "azcopy", "copy",
                file.getAbsolutePath(),
                sasUrl,
                "--quiet",
                "--log-level=ERROR"
        );

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        pb.environment().put("AZCOPY_LOG_LOCATION", tempAzCopyLogDir.getAbsolutePath());
        pb.inheritIO();

        Process process = pb.start();
        int exitCode = process.waitFor();

        deleteDirectoryRecursively(tempAzCopyLogDir);

        return exitCode == 0;
    }

    private static void deleteDirectoryRecursively(File dir) {
        if (dir.isDirectory()) {
            File[] children = dir.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteDirectoryRecursively(child);
                }
            }
        }
        dir.delete();
    }

    private static class AprimoTokenManager {
        private String accessToken;
        private long expiryTimeMillis;

        private static final ObjectMapper mapper = new ObjectMapper();

        public synchronized String getValidToken() throws IOException {
            if (accessToken == null || System.currentTimeMillis() > expiryTimeMillis - 60_000) {
                refreshToken();
            }
            return accessToken;
        }

        private void refreshToken() throws IOException {
            try (CloseableHttpClient client = HttpClients.createDefault()) {
                HttpPost post = new HttpPost(APRIMO_TOKEN_URL);
                post.setHeader(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded");

                String body = "grant_type=client_credentials"
                        + "&client_id=" + URLEncoder.encode(APRIMO_CLIENT_ID, StandardCharsets.UTF_8.name())
                        + "&client_secret=" + URLEncoder.encode(APRIMO_CLIENT_SECRET, StandardCharsets.UTF_8.name())
                        + "&scope=api";

                post.setEntity(new StringEntity(body, StandardCharsets.UTF_8));

                try (CloseableHttpResponse response = client.execute(post)) {
                    int statusCode = response.getStatusLine().getStatusCode();
                    if (statusCode != 200) {
                        throw new IOException("Failed to get Aprimo token: " + statusCode);
                    }

                    JsonNode json = mapper.readTree(response.getEntity().getContent());
                    accessToken = json.get("access_token").asText();
                    int expiresIn = json.get("expires_in").asInt();
                    expiryTimeMillis = System.currentTimeMillis() + (expiresIn * 1000L);

                    System.out.println("🔄 New Aprimo token acquired. Valid for " + expiresIn + " seconds.");
                }
            }
        }
    }

    private static final AprimoTokenManager tokenManager = new AprimoTokenManager();

    private static String getAprimoToken() throws IOException {
        return tokenManager.getValidToken();
    }

    private static void uploadFileToSharePoint(String spToken, File file) {
        try {
            if (file == null || !file.exists()) {
                System.err.println("❌ File not found for upload: " + (file != null ? file.getAbsolutePath() : "null"));
                return;
            }

            String encodedFileName = URLEncoder.encode(file.getName(), StandardCharsets.UTF_8);
            String uploadUrl = String.format(
                    "https://graph.microsoft.com/v1.0/drives/%s/root:/%s:/content",
                    SP_DRIVE_ID,
                    encodedFileName
            );

            HttpPut put = new HttpPut(uploadUrl);
            put.setHeader("Authorization", "Bearer " + spToken);
            put.setEntity(new FileEntity(file));

            try (CloseableHttpClient client = HttpClients.createDefault();
                 CloseableHttpResponse response = client.execute(put)) {

                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    System.out.println("✅ Log file uploaded to SharePoint: " + file.getName());
                } else {
                    System.err.println("❌ Failed to upload log (HTTP " + status + ")");
                    System.err.println("🔍 URL: " + uploadUrl);
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Unexpected error during SharePoint upload.");
            e.printStackTrace();
        }
    }

    public static String uploadCsvAndGetToken(File csvFile, String aprimoToken) throws IOException {
        String url = "https://partnerdemo103.aprimo.com/uploads";
        try (CloseableHttpClient client = HttpClients.createDefault()) {
            HttpPost post = new HttpPost(url);
            post.setHeader(HttpHeaders.AUTHORIZATION, "Bearer " + aprimoToken);
            post.setHeader("API-VERSION", "1");

            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addBinaryBody("file", csvFile, ContentType.DEFAULT_BINARY, csvFile.getName());
            post.setEntity(builder.build());

            try (CloseableHttpResponse response = client.execute(post)) {
                int status = response.getStatusLine().getStatusCode();
                String body = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))
                        .lines().reduce("", (a, b) -> a + b);

                System.out.println("🔍 Metadata Upload Response (" + status + "):");
                System.out.println(body);

                if (status >= 200 && status < 300) {
                    ObjectMapper mapper = new ObjectMapper();
                    JsonNode json = mapper.readTree(body);
                    if (json.has("token")) {
                        return json.get("token").asText();
                    } else {
                        throw new IOException("❌ 'token' not found in response: " + json.toPrettyString());
                    }
                } else {
                    throw new IOException("❌ Metadata upload failed: " + status + " - " + body);
                }
            }
        }
    }

    public static String createAssetRecordAndReturnId(CloseableHttpClient client, String aprimoToken, String uploadToken, String metadataToken, String fileName) throws IOException {
        String url = "https://partnerdemo103.dam.aprimo.com/api/core/records";
        ObjectMapper mapper = new ObjectMapper();

        HttpPost post = new HttpPost(url);
        post.setHeader("Authorization", "Bearer " + aprimoToken);
        post.setHeader("API-VERSION", "1");
        post.setHeader("Content-Type", "application/json");
        post.setHeader("Accept", "application/json");

        ObjectNode root = mapper.createObjectNode();
        root.put("status", "draft");

        ObjectNode filesNode = root.putObject("files");
        filesNode.put("master", uploadToken);

        ObjectNode version = mapper.createObjectNode();
        version.put("id", uploadToken);
        version.put("fileName", fileName);
        version.put("versionLabel", "v1");
        version.put("comment", "Uploaded from SharePoint");

        ObjectNode versionWrap = mapper.createObjectNode();
        versionWrap.set("addOrUpdate", mapper.createArrayNode().add(version));

        ObjectNode fileWrap = mapper.createObjectNode();
        fileWrap.set("versions", versionWrap);

        filesNode.set("addOrUpdate", mapper.createArrayNode().add(fileWrap));

        if (metadataToken != null && !metadataToken.isEmpty()) {
            ObjectNode metadataNode = root.putObject("metadata");
            metadataNode.put("name", "UpdateAssetMetadata");
            metadataNode.put("token", metadataToken);
            metadataNode.put("metadataMatchField", "FileName");
        }

        post.setEntity(new StringEntity(mapper.writeValueAsString(root), ContentType.APPLICATION_JSON));

        try (CloseableHttpResponse response = client.execute(post)) {
            int status = response.getStatusLine().getStatusCode();
            String responseBody = new BufferedReader(new InputStreamReader(response.getEntity().getContent()))
                    .lines().reduce("", (a, b) -> a + b);

            if (status >= 200 && status < 300) {
                JsonNode responseJson = mapper.readTree(responseBody);
                String recordId = responseJson.has("id") ? responseJson.get("id").asText() : "-";
                System.out.println("✅ Asset created for: " + fileName + " | Record ID: " + recordId);
                return recordId;
            } else {
                throw new IOException("❌ Failed to create asset: " + status + " - " + responseBody);
            }
        }
    }
}