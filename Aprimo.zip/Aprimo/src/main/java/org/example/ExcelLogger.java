package org.example;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.concurrent.atomic.AtomicInteger;

public class ExcelLogger {
    private final String filePath;
    private final Workbook workbook;
    private final Sheet sheet;
    private final AtomicInteger rowIndex = new AtomicInteger(1); // Start after header

    private final String[] headers = {
            "File Name", "Folder Path", "Download Status", "Upload Status",
            "Download Time", "Upload Time", "Error Message", "Metadata Status", "Record ID"
    };

    public ExcelLogger(String filePath) throws IOException {
        this.filePath = filePath;
        File file = new File(filePath);

        if (file.exists()) {
            try (FileInputStream fis = new FileInputStream(file)) {
                workbook = new XSSFWorkbook(fis);
                sheet = workbook.getSheetAt(0);
                rowIndex.set(sheet.getLastRowNum() + 1); // resume from last row
            }
        } else {
            workbook = new XSSFWorkbook();
            sheet = workbook.createSheet("Migration Log details");
            createHeader();
            save(); // write header immediately
        }
    }

    private void createHeader() {
        Row headerRow = sheet.createRow(0);
        for (int i = 0; i < headers.length; i++) {
            headerRow.createCell(i).setCellValue(headers[i]);
        }
    }

    public synchronized void log(LogEntry entry) {
        Row row = sheet.createRow(rowIndex.getAndIncrement());

        row.createCell(0).setCellValue(entry.fileName);
        row.createCell(1).setCellValue(entry.folderPath);
        row.createCell(2).setCellValue(entry.downloadStatus);
        row.createCell(3).setCellValue(entry.uploadStatus);
        row.createCell(4).setCellValue(entry.downloadTime);
        row.createCell(5).setCellValue(entry.uploadTime);
        row.createCell(6).setCellValue(entry.errorMessage != null ? entry.errorMessage : "");
        row.createCell(7).setCellValue(entry.metadataStatus);
        row.createCell(8).setCellValue(entry.recordId != null ? entry.recordId : "-");

        try {
            save(); // durable: write after each log
            System.out.println("📝 Logged: " + entry.fileName);
        } catch (IOException e) {
            System.err.println("❌ Failed to write log for " + entry.fileName + ": " + e.getMessage());
        }
    }

    private void save() throws IOException {
        try (FileOutputStream fos = new FileOutputStream(filePath)) {
            workbook.write(fos);
        }
    }

    public void close() throws IOException {
        workbook.close();
    }

    public File getFile() {
        return new File(filePath);
    }
}
