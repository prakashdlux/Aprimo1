package org.example;

public class LogEntry {
    public final String fileName;
    public final String folderPath;       // 📁 Folder path (from SharePoint)
    public final String downloadStatus;
    public final String uploadStatus;
    public final String downloadTime;
    public final String uploadTime;
    public final String errorMessage;
    public final String metadataStatus;
    public final String recordId;         // 🆔 Aprimo asset record ID

    public LogEntry(String fileName, String folderPath, String downloadStatus, String uploadStatus,
                    String downloadTime, String uploadTime, String errorMessage,
                    String metadataStatus, String recordId) {
        this.fileName = fileName;
        this.folderPath = folderPath;
        this.downloadStatus = downloadStatus;
        this.uploadStatus = uploadStatus;
        this.downloadTime = downloadTime;
        this.uploadTime = uploadTime;
        this.errorMessage = errorMessage;
        this.metadataStatus = metadataStatus;
        this.recordId = recordId;
    }
}
